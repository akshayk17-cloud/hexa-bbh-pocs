package com.example.demo.service;
 
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
 
import java.util.ArrayList;
import java.util.List;
 
@Service
public class UserService {
 
    @Autowired
    private UserRepository userRepository;
 
    @PersistenceContext
    private EntityManager entityManager;
 
    public Page<User> getUsers(int page, int size, String sortBy, String sortDirection, String nameFilter, String emailFilter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<User> cq = cb.createQuery(User.class);
        Root<User> root = cq.from(User.class);
 
        // 🔹 Apply filtering predicates
        List<Predicate> predicates = new ArrayList<>();
 
        if (nameFilter != null && !nameFilter.isEmpty()) {
            predicates.add(cb.like(cb.lower(root.get("name")), "%" + nameFilter.toLowerCase() + "%"));
        	//predicates.add(cb.like(root.get("name"), "%" + nameFilter + "%"));
        }
        
 
        if (emailFilter != null && !emailFilter.isEmpty()) {
            predicates.add(cb.like(cb.lower(root.get("email")), "%" + emailFilter.toLowerCase() + "%"));
        }
 
        // Apply filtering conditions
        if (!predicates.isEmpty()) {
            cq.where(predicates.toArray(new Predicate[0]));
        }
 
        // 🔹 Apply sorting
        Sort.Direction direction = Sort.Direction.fromString(sortDirection);
        Order order = direction == Sort.Direction.ASC ? cb.asc(root.get(sortBy)) : cb.desc(root.get(sortBy));
        cq.orderBy(order);
 
        // 🔹 Pagination
        TypedQuery<User> query = entityManager.createQuery(cq);
        query.setFirstResult(page * size);
        query.setMaxResults(size);
 
        // 🔹 Get paginated results
        List<User> users = query.getResultList();
 
        // Get total count for pagination
        CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);
        Root<User> countRoot = countQuery.from(User.class);
        countQuery.select(cb.count(countRoot));
        //if (!predicates.isEmpty()) {
            //countQuery.where(predicates.toArray(new Predicate[0]));
        //}
        
        List<Long> resultList = entityManager.createQuery(countQuery).getResultList();
        Long totalRecords = resultList.isEmpty() ? 0L : resultList.get(0);
        
        //Long totalRecords = entityManager.createQuery(countQuery).getSingleResult();
 
Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));
        return new PageImpl<>(users, pageable, totalRecords);
    }
}

































//package com.example.demo.service;
// 
//import com.example.demo.entity.User;
//import com.example.demo.repository.UserRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.*;
//import org.springframework.stereotype.Service;
// 
//@Service
//public class UserService {
// 
//    @Autowired
//    private UserRepository userRepository;
// 
//    public Page<User> getUsers(int page, int size, String sortBy, String sortDirection) {
//        Sort.Direction direction;
//        
//        try {
//            direction = Sort.Direction.fromString(sortDirection);
//        } catch (IllegalArgumentException e) {
//            direction = Sort.Direction.ASC;  // Default to ASC if invalid input
//        }
// 
//Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortBy));
// 
//        // Ensure findAll() returns a Page<User>
//        return userRepository.findAll(pageable);
//    }
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
////package com.example.demo.service;
////
////import com.example.demo.entity.User;
////import com.example.demo.repository.UserRepository;
////
////import java.awt.print.Pageable;
////
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.data.domain.Page;
////import org.springframework.data.domain.PageRequest;
////import org.springframework.data.domain.Sort;
////import org.springframework.stereotype.Service;
//// 
////@Service
////public class UserService {
////    
////    @Autowired
////    private UserRepository userRepository;
//// 
////    public Page<User> getUsers(int page, int size, String sortBy, String sortDirection) {
////    	Sort.Direction direction = Sort.Direction.fromString(sortDirection);
////    	
////    	Pageable pageable = (Pageable) PageRequest.of(page, size, Sort.by(direction, sortBy));
////        return userRepository.findAll(pageable);
////    }
////}
