//package com.example.demo;
//
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//@SpringBootApplication
//public class HibernatePaginationApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(HibernatePaginationApplication.class, args);
//	}
//
//}

package com.example.demo;
 
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
 
@SpringBootApplication
public class HibernatePaginationApplication implements CommandLineRunner {
 
    @Autowired
    private UserRepository userRepository;
 
    public static void main(String[] args) {
SpringApplication.run(HibernatePaginationApplication.class, args);
    }
 
    @Override
    public void run(String... args) throws Exception {
        // Pre-load some data
    	
    	userRepository.deleteAll();
    	
//    	User user = new User();
//    	user.setEmail("ak@gmail.com");
//    	user.setName("Akshay");
//    	userRepository.save(user);
    	
//    	userRepository.saveAll(List.of(
//    			new User(null, "John Doe", "john@example.com"),
//    			new User(null, "Jane Smith", "jane@example.com"),
//    			new User(null, "Bob Brown", "bob@example.com")
//    			));
    	
    	System.out.println("Sample data inserted successfully...");
    	
        userRepository.save(new User("John Doe", "john@example.com"));
        userRepository.save(new User("Jane Smith", "jane@example.com"));
        userRepository.save(new User("Bob Brown", "bob@example.com"));
        userRepository.save(new User("Tom", "tom@example.com"));
        userRepository.save(new User("Joss", "joss@example.com"));
        userRepository.save(new User("Nick", "nick@example.com"));
        userRepository.save(new User("Amy Toson", "amy@example.com"));
        userRepository.save(new User("Brooke", "brooke@example.com"));
        userRepository.save(new User("Rock", "rock@example.com"));
        userRepository.save(new User("Rock2", "rock2@example.com"));
    }
}
