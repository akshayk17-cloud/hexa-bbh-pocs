package com.example.demo.controller;
 
import com.example.demo.entity.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;
 
@RestController
@RequestMapping("/users")
public class UserController {
 
    @Autowired
    private UserService userService;
 
    @GetMapping
    public Page<User> getUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDirection,
            @RequestParam(required = false) String nameFilter,
            @RequestParam(required = false) String emailFilter) {
        return userService.getUsers(page, size, sortBy, sortDirection, nameFilter, emailFilter);
    }
}
























//package com.example.demo.controller;
// 
//import com.example.demo.entity.User;
//import com.example.demo.service.UserService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Page;
//import org.springframework.web.bind.annotation.*;
// 
//@RestController
//@RequestMapping("/users")
//public class UserController {
// 
//    @Autowired
//    private UserService userService;
// 
//    @GetMapping
//    public Page<User> getUsers(
//            @RequestParam(defaultValue = "0") int page,
//            @RequestParam(defaultValue = "5") int size,
//            @RequestParam(defaultValue = "id") String sortBy,
//            @RequestParam(defaultValue = "asc") String sortDirection) {
//        return userService.getUsers(page, size, sortBy, sortDirection);
//    }
//}
//
//
//
//
//
//
//
//
//
////package com.example.demo.controller;
////
////import com.example.demo.entity.User;
////import com.example.demo.service.UserService;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.data.domain.Page;
////import org.springframework.web.bind.annotation.GetMapping;
////import org.springframework.web.bind.annotation.RequestParam;
////import org.springframework.web.bind.annotation.RestController;
//// 
////@RestController
////public class UserController {
//// 
////    @Autowired
////    private UserService userService;
//// 
////    @GetMapping("/users")
////    public Page<User> getUsers(
////            @RequestParam(defaultValue = "0") int page,
////            @RequestParam(defaultValue = "5") int size) {
////        return userService.getUsers(page, size);
////    }
////}
